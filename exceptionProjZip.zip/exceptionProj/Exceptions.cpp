// Exceptions.cpp : This file contains the 'main' function.Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

class Exception : public std::runtime_error {
public:
    // Define constructor of class Exception, pass a string message to the runtime_error class
    Exception()
        : runtime_error("Custom exception\n")
    {
    }
};


bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    throw std::bad_cast();

    return true;
}
void do_custom_application_logic()
{

    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

   try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::bad_cast& e) {
        std::cout << "e.what(): " << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    throw Exception();

    std::cout << "Leaving Custom Application Logic." << std::endl;
   
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
 
    throw std::runtime_error("Math error: Attempted to divide by Zero\n");
    
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::runtime_error& e) {

        // prints that exception has occurred and what
        std::cout << "Exception occurred" << std::endl
            << e.what();
    }
}

int main()
{
    try {
        bool temp;

        std::cout << "Exceptions Tests!" << std::endl;

        // TODO: Create exception handlers that catch (in this order):
        //  your custom exception
        try {
            do_custom_application_logic();
        }
        catch (Exception& e) {

            // prints exception occurred, calls what function
            std::cout << "Exception occurred" << std::endl
                << e.what();
        }


        //  std::exception
        try {
            temp = do_even_more_custom_application_logic();
        }
        catch (const std::bad_cast& e) {
            std::cout << "Standard Exception: caught bad_cast " << std::endl;
        }
        
        do_division();
        do_custom_application_logic();
    }
    //  uncaught exception 
        //  that wraps the whole main function, and displays a message to the console.
    catch (const std::exception& e) {
        std::cout << "Uncaught Exception caught: " << e.what() << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu